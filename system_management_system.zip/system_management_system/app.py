"""System Management System - Flask application.

Run with:  python app.py
"""
import csv
import io
import re
import secrets
from datetime import datetime, timedelta
from functools import wraps
from math import ceil

from flask import (Flask, Response, abort, flash, g, redirect, render_template,
                   request, session, url_for)
from werkzeug.security import check_password_hash, generate_password_hash

import database as db
from config import Config

# ------------------------------------------------------------------ constants
USER_ROLES = ["Manager", "Staff", "Student", "Guest"]
USER_STATUSES = ["Active", "Inactive", "Suspended"]
RECORD_CATEGORIES = ["Hardware", "Software", "Network", "Security", "Maintenance", "Other"]
RECORD_STATUSES = ["Open", "In Progress", "Completed", "Archived"]
RECORD_PRIORITIES = ["Low", "Medium", "High"]

EMAIL_RE = re.compile(r"^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}$")
PHONE_RE = re.compile(r"^[0-9+\-\s]{7,15}$")
USERNAME_RE = re.compile(r"^[A-Za-z0-9_.-]{3,30}$")


def create_app(config_object=Config):
    app = Flask(__name__)
    app.config.from_object(config_object)
    db.init_db(app)
    app.teardown_appcontext(db.close_db)

    # ------------------------------------------------------------- helpers
    def per_page():
        try:
            return max(3, min(50, int(db.get_setting("items_per_page", "8"))))
        except ValueError:
            return 8

    def paginate(count_sql, data_sql, args):
        """Return a dict with items and pagination info."""
        size = per_page()
        total = db.query(count_sql, args, one=True)[0]
        pages = max(1, ceil(total / size))
        try:
            page = int(request.args.get("page", 1))
        except ValueError:
            page = 1
        page = min(max(page, 1), pages)
        items = db.query(data_sql + " LIMIT ? OFFSET ?", list(args) + [size, (page - 1) * size])
        return {"items": items, "page": page, "pages": pages, "total": total, "per_page": size}

    def log(action, entity, details=""):
        db.log_activity(g.admin["id"] if g.get("admin") else None, action, entity, details)

    def login_required(view):
        @wraps(view)
        def wrapped(*args, **kwargs):
            if g.admin is None:
                flash("Please log in to continue.", "warning")
                return redirect(url_for("login", next=request.path))
            return view(*args, **kwargs)
        return wrapped

    def is_safe_next(target):
        return bool(target) and target.startswith("/") and not target.startswith("//")

    # ------------------------------------------------------ request hooks
    @app.before_request
    def load_admin_and_check_csrf():
        g.admin = None
        admin_id = session.get("admin_id")
        if admin_id:
            g.admin = db.query("SELECT * FROM admin WHERE id = ?", (admin_id,), one=True)
            if g.admin is None:
                session.clear()
        if app.config["CSRF_ENABLED"] and request.method == "POST":
            sent = request.form.get("csrf_token", "")
            expected = session.get("_csrf_token", "")
            if not expected or not secrets.compare_digest(sent, expected):
                abort(400, description="Invalid or missing CSRF token. Please reload the page and try again.")

    @app.context_processor
    def inject_globals():
        def csrf_token():
            if "_csrf_token" not in session:
                session["_csrf_token"] = secrets.token_hex(16)
            return session["_csrf_token"]
        return {
            "csrf_token": csrf_token,
            "system_name": db.get_setting("system_name", "System Management System"),
            "organization": db.get_setting("organization", ""),
            "current_year": datetime.now().year,
        }

    @app.after_request
    def security_headers(resp):
        resp.headers["X-Content-Type-Options"] = "nosniff"
        resp.headers["X-Frame-Options"] = "SAMEORIGIN"
        resp.headers["Cache-Control"] = "no-store"
        return resp

    @app.errorhandler(400)
    def bad_request(e):
        return render_template("error.html", code=400, title="Bad Request", message=e.description), 400

    @app.errorhandler(404)
    def not_found(e):
        return render_template("error.html", code=404, title="Page Not Found",
                               message="The page you are looking for does not exist."), 404

    @app.errorhandler(500)
    def server_error(e):
        return render_template("error.html", code=500, title="Server Error",
                               message="Something went wrong on our side."), 500

    # ---------------------------------------------------------- auth
    @app.route("/")
    def index():
        return redirect(url_for("dashboard" if g.admin else "login"))

    @app.route("/login", methods=["GET", "POST"])
    def login():
        if g.admin:
            return redirect(url_for("dashboard"))
        errors = {}
        username = ""
        if request.method == "POST":
            username = request.form.get("username", "").strip()
            password = request.form.get("password", "")
            if not username:
                errors["username"] = "Username is required."
            if not password:
                errors["password"] = "Password is required."
            if not errors:
                admin = db.query("SELECT * FROM admin WHERE username = ?", (username,), one=True)
                if admin and check_password_hash(admin["password_hash"], password):
                    session.clear()
                    session["admin_id"] = admin["id"]
                    session.permanent = True
                    g.admin = admin
                    log("Login", "Session", "Administrator signed in")
                    flash(f"Welcome back, {admin['full_name']}!", "success")
                    nxt = request.args.get("next", "")
                    return redirect(nxt if is_safe_next(nxt) else url_for("dashboard"))
                flash("Invalid username or password.", "danger")
        return render_template("login.html", errors=errors, username=username)

    @app.route("/logout", methods=["POST"])
    @login_required
    def logout():
        log("Logout", "Session", "Administrator signed out")
        session.clear()
        flash("You have been logged out.", "info")
        return redirect(url_for("login"))

    # ---------------------------------------------------- dashboard
    @app.route("/dashboard")
    @login_required
    def dashboard():
        stats = {
            "users": db.query("SELECT COUNT(*) FROM users", one=True)[0],
            "active_users": db.query("SELECT COUNT(*) FROM users WHERE status='Active'", one=True)[0],
            "records": db.query("SELECT COUNT(*) FROM system_records", one=True)[0],
            "open_records": db.query(
                "SELECT COUNT(*) FROM system_records WHERE status IN ('Open','In Progress')", one=True)[0],
            "activities": db.query("SELECT COUNT(*) FROM activity_logs", one=True)[0],
        }
        recent = db.query(
            "SELECT a.*, ad.username FROM activity_logs a LEFT JOIN admin ad ON ad.id = a.admin_id "
            "ORDER BY a.id DESC LIMIT 8")
        by_category = db.query("SELECT category, COUNT(*) c FROM system_records GROUP BY category ORDER BY category")
        by_status = db.query("SELECT status, COUNT(*) c FROM system_records GROUP BY status ORDER BY status")
        by_role = db.query("SELECT role, COUNT(*) c FROM users GROUP BY role ORDER BY role")
        days, counts = [], []
        for i in range(6, -1, -1):
            d = datetime.now() - timedelta(days=i)
            days.append(d.strftime("%d %b"))
            counts.append(db.query("SELECT COUNT(*) FROM activity_logs WHERE date(created_at) = ?",
                                   (d.strftime("%Y-%m-%d"),), one=True)[0])
        chart = {
            "category": {"labels": [r["category"] for r in by_category], "data": [r["c"] for r in by_category]},
            "status": {"labels": [r["status"] for r in by_status], "data": [r["c"] for r in by_status]},
            "role": {"labels": [r["role"] for r in by_role], "data": [r["c"] for r in by_role]},
            "activity": {"labels": days, "data": counts},
        }
        return render_template("dashboard.html", stats=stats, recent=recent, chart=chart)

    # ------------------------------------------------------ users
    def validate_user(form, user_id=None):
        data = {
            "full_name": form.get("full_name", "").strip(),
            "email": form.get("email", "").strip().lower(),
            "phone": form.get("phone", "").strip(),
            "role": form.get("role", ""),
            "department": form.get("department", "").strip(),
            "status": form.get("status", "Active"),
        }
        errors = {}
        if not 2 <= len(data["full_name"]) <= 80:
            errors["full_name"] = "Full name must be 2 to 80 characters."
        if not EMAIL_RE.match(data["email"]):
            errors["email"] = "Enter a valid email address."
        else:
            dup = db.query("SELECT id FROM users WHERE email = ? AND id != ?", (data["email"], user_id or 0), one=True)
            if dup:
                errors["email"] = "This email is already registered."
        if data["phone"] and not PHONE_RE.match(data["phone"]):
            errors["phone"] = "Phone must be 7-15 digits (digits, +, - and spaces allowed)."
        if data["role"] not in USER_ROLES:
            errors["role"] = "Select a valid role."
        if data["status"] not in USER_STATUSES:
            errors["status"] = "Select a valid status."
        if len(data["department"]) > 60:
            errors["department"] = "Department must be at most 60 characters."
        return data, errors

    @app.route("/users")
    @login_required
    def users():
        q = request.args.get("q", "").strip()
        status = request.args.get("status", "")
        role = request.args.get("role", "")
        where, args = ["1=1"], []
        if q:
            where.append("(full_name LIKE ? OR email LIKE ? OR department LIKE ?)")
            args += [f"%{q}%"] * 3
        if status in USER_STATUSES:
            where.append("status = ?")
            args.append(status)
        if role in USER_ROLES:
            where.append("role = ?")
            args.append(role)
        w = " AND ".join(where)
        page = paginate(f"SELECT COUNT(*) FROM users WHERE {w}",
                        f"SELECT * FROM users WHERE {w} ORDER BY id DESC", args)
        return render_template("users.html", page=page, q=q, status=status, role=role,
                               roles=USER_ROLES, statuses=USER_STATUSES)

    @app.route("/users/add", methods=["GET", "POST"])
    @login_required
    def user_add():
        data, errors = {"status": "Active", "role": "Staff"}, {}
        if request.method == "POST":
            data, errors = validate_user(request.form)
            if not errors:
                db.execute(
                    "INSERT INTO users (full_name, email, phone, role, department, status, created_at) VALUES (?,?,?,?,?,?,?)",
                    (data["full_name"], data["email"], data["phone"], data["role"], data["department"],
                     data["status"], datetime.now().strftime("%Y-%m-%d %H:%M:%S")))
                log("Create", "User", f"Added user '{data['full_name']}'")
                flash("User added successfully.", "success")
                return redirect(url_for("users"))
            flash("Please correct the errors below.", "danger")
        return render_template("user_form.html", data=data, errors=errors, mode="add",
                               roles=USER_ROLES, statuses=USER_STATUSES)

    @app.route("/users/<int:user_id>/edit", methods=["GET", "POST"])
    @login_required
    def user_edit(user_id):
        user = db.query("SELECT * FROM users WHERE id = ?", (user_id,), one=True)
        if user is None:
            abort(404)
        data, errors = dict(user), {}
        if request.method == "POST":
            data, errors = validate_user(request.form, user_id)
            if not errors:
                db.execute(
                    "UPDATE users SET full_name=?, email=?, phone=?, role=?, department=?, status=? WHERE id=?",
                    (data["full_name"], data["email"], data["phone"], data["role"], data["department"],
                     data["status"], user_id))
                log("Update", "User", f"Updated user '{data['full_name']}'")
                flash("User updated successfully.", "success")
                return redirect(url_for("users"))
            flash("Please correct the errors below.", "danger")
        return render_template("user_form.html", data=data, errors=errors, mode="edit", user_id=user_id,
                               roles=USER_ROLES, statuses=USER_STATUSES)

    @app.route("/users/<int:user_id>/status", methods=["POST"])
    @login_required
    def user_status(user_id):
        user = db.query("SELECT * FROM users WHERE id = ?", (user_id,), one=True)
        if user is None:
            abort(404)
        new_status = request.form.get("status", "")
        if new_status not in USER_STATUSES:
            flash("Invalid status.", "danger")
        else:
            db.execute("UPDATE users SET status = ? WHERE id = ?", (new_status, user_id))
            log("Update", "User", f"Changed status of '{user['full_name']}' to {new_status}")
            flash(f"{user['full_name']} is now {new_status}.", "success")
        return redirect(request.referrer or url_for("users"))

    @app.route("/users/<int:user_id>/delete", methods=["POST"])
    @login_required
    def user_delete(user_id):
        user = db.query("SELECT * FROM users WHERE id = ?", (user_id,), one=True)
        if user is None:
            abort(404)
        db.execute("DELETE FROM users WHERE id = ?", (user_id,))
        log("Delete", "User", f"Deleted user '{user['full_name']}'")
        flash("User deleted.", "success")
        return redirect(url_for("users"))

    # ---------------------------------------------------- records
    def validate_record(form):
        data = {
            "title": form.get("title", "").strip(),
            "category": form.get("category", ""),
            "description": form.get("description", "").strip(),
            "status": form.get("status", "Open"),
            "priority": form.get("priority", "Medium"),
            "assigned_user_id": form.get("assigned_user_id", "").strip(),
        }
        errors = {}
        if not 3 <= len(data["title"]) <= 120:
            errors["title"] = "Title must be 3 to 120 characters."
        if data["category"] not in RECORD_CATEGORIES:
            errors["category"] = "Select a valid category."
        if data["status"] not in RECORD_STATUSES:
            errors["status"] = "Select a valid status."
        if data["priority"] not in RECORD_PRIORITIES:
            errors["priority"] = "Select a valid priority."
        if len(data["description"]) > 500:
            errors["description"] = "Description must be at most 500 characters."
        if data["assigned_user_id"]:
            if not data["assigned_user_id"].isdigit() or not db.query(
                    "SELECT id FROM users WHERE id = ?", (int(data["assigned_user_id"]),), one=True):
                errors["assigned_user_id"] = "Selected user does not exist."
        return data, errors

    @app.route("/records")
    @login_required
    def records():
        q = request.args.get("q", "").strip()
        category = request.args.get("category", "")
        status = request.args.get("status", "")
        where, args = ["1=1"], []
        if q:
            where.append("(r.title LIKE ? OR r.description LIKE ?)")
            args += [f"%{q}%"] * 2
        if category in RECORD_CATEGORIES:
            where.append("r.category = ?")
            args.append(category)
        if status in RECORD_STATUSES:
            where.append("r.status = ?")
            args.append(status)
        w = " AND ".join(where)
        page = paginate(
            f"SELECT COUNT(*) FROM system_records r WHERE {w}",
            "SELECT r.*, u.full_name AS assignee FROM system_records r "
            f"LEFT JOIN users u ON u.id = r.assigned_user_id WHERE {w} ORDER BY r.id DESC", args)
        return render_template("records.html", page=page, q=q, category=category, status=status,
                               categories=RECORD_CATEGORIES, statuses=RECORD_STATUSES)

    def record_form_context():
        return {
            "categories": RECORD_CATEGORIES, "statuses": RECORD_STATUSES, "priorities": RECORD_PRIORITIES,
            "all_users": db.query("SELECT id, full_name FROM users ORDER BY full_name"),
        }

    @app.route("/records/add", methods=["GET", "POST"])
    @login_required
    def record_add():
        data, errors = {"status": "Open", "priority": "Medium"}, {}
        if request.method == "POST":
            data, errors = validate_record(request.form)
            if not errors:
                now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                db.execute(
                    "INSERT INTO system_records (title, category, description, status, priority, assigned_user_id, "
                    "created_by, created_at, updated_at) VALUES (?,?,?,?,?,?,?,?,?)",
                    (data["title"], data["category"], data["description"], data["status"], data["priority"],
                     int(data["assigned_user_id"]) if data["assigned_user_id"] else None, g.admin["id"], now, now))
                log("Create", "Record", f"Added record '{data['title']}'")
                flash("Record created successfully.", "success")
                return redirect(url_for("records"))
            flash("Please correct the errors below.", "danger")
        return render_template("record_form.html", data=data, errors=errors, mode="add", **record_form_context())

    @app.route("/records/<int:record_id>/edit", methods=["GET", "POST"])
    @login_required
    def record_edit(record_id):
        rec = db.query("SELECT * FROM system_records WHERE id = ?", (record_id,), one=True)
        if rec is None:
            abort(404)
        data, errors = dict(rec), {}
        data["assigned_user_id"] = str(rec["assigned_user_id"] or "")
        if request.method == "POST":
            data, errors = validate_record(request.form)
            if not errors:
                db.execute(
                    "UPDATE system_records SET title=?, category=?, description=?, status=?, priority=?, "
                    "assigned_user_id=?, updated_at=? WHERE id=?",
                    (data["title"], data["category"], data["description"], data["status"], data["priority"],
                     int(data["assigned_user_id"]) if data["assigned_user_id"] else None,
                     datetime.now().strftime("%Y-%m-%d %H:%M:%S"), record_id))
                log("Update", "Record", f"Updated record '{data['title']}'")
                flash("Record updated successfully.", "success")
                return redirect(url_for("records"))
            flash("Please correct the errors below.", "danger")
        return render_template("record_form.html", data=data, errors=errors, mode="edit",
                               record_id=record_id, **record_form_context())

    @app.route("/records/<int:record_id>")
    @login_required
    def record_view(record_id):
        rec = db.query(
            "SELECT r.*, u.full_name AS assignee, a.full_name AS creator FROM system_records r "
            "LEFT JOIN users u ON u.id = r.assigned_user_id LEFT JOIN admin a ON a.id = r.created_by "
            "WHERE r.id = ?", (record_id,), one=True)
        if rec is None:
            abort(404)
        return render_template("record_view.html", rec=rec)

    @app.route("/records/<int:record_id>/delete", methods=["POST"])
    @login_required
    def record_delete(record_id):
        rec = db.query("SELECT * FROM system_records WHERE id = ?", (record_id,), one=True)
        if rec is None:
            abort(404)
        db.execute("DELETE FROM system_records WHERE id = ?", (record_id,))
        log("Delete", "Record", f"Deleted record '{rec['title']}'")
        flash("Record deleted.", "success")
        return redirect(url_for("records"))

    # -------------------------------------------------- activities
    @app.route("/activities")
    @login_required
    def activities():
        q = request.args.get("q", "").strip()
        action = request.args.get("action", "")
        where, args = ["1=1"], []
        if q:
            where.append("(a.details LIKE ? OR a.entity LIKE ?)")
            args += [f"%{q}%"] * 2
        if action:
            where.append("a.action = ?")
            args.append(action)
        w = " AND ".join(where)
        page = paginate(
            f"SELECT COUNT(*) FROM activity_logs a WHERE {w}",
            "SELECT a.*, ad.username FROM activity_logs a LEFT JOIN admin ad ON ad.id = a.admin_id "
            f"WHERE {w} ORDER BY a.id DESC", args)
        actions = [r["action"] for r in db.query("SELECT DISTINCT action FROM activity_logs ORDER BY action")]
        return render_template("activities.html", page=page, q=q, action=action, actions=actions)

    # ----------------------------------------------------- reports
    @app.route("/reports")
    @login_required
    def reports():
        summary = {
            "total_users": db.query("SELECT COUNT(*) FROM users", one=True)[0],
            "total_records": db.query("SELECT COUNT(*) FROM system_records", one=True)[0],
            "total_activities": db.query("SELECT COUNT(*) FROM activity_logs", one=True)[0],
            "high_priority_open": db.query(
                "SELECT COUNT(*) FROM system_records WHERE priority='High' AND status IN ('Open','In Progress')",
                one=True)[0],
            "unassigned": db.query(
                "SELECT COUNT(*) FROM system_records WHERE assigned_user_id IS NULL", one=True)[0],
        }
        users_by_status = db.query("SELECT status, COUNT(*) c FROM users GROUP BY status ORDER BY status")
        users_by_role = db.query("SELECT role, COUNT(*) c FROM users GROUP BY role ORDER BY role")
        rec_by_cat = db.query("SELECT category, COUNT(*) c FROM system_records GROUP BY category ORDER BY category")
        rec_by_status = db.query("SELECT status, COUNT(*) c FROM system_records GROUP BY status ORDER BY status")
        rec_by_priority = db.query("SELECT priority, COUNT(*) c FROM system_records GROUP BY priority ORDER BY priority")
        completed = db.query("SELECT COUNT(*) FROM system_records WHERE status='Completed'", one=True)[0]
        summary["completion_rate"] = round(completed * 100 / summary["total_records"], 1) if summary["total_records"] else 0
        return render_template(
            "reports.html", summary=summary, users_by_status=users_by_status, users_by_role=users_by_role,
            rec_by_cat=rec_by_cat, rec_by_status=rec_by_status, rec_by_priority=rec_by_priority,
            generated=datetime.now().strftime("%d %B %Y, %I:%M %p"))

    def csv_response(filename, header, rows):
        buf = io.StringIO()
        writer = csv.writer(buf)
        writer.writerow(header)
        writer.writerows(rows)
        return Response(buf.getvalue(), mimetype="text/csv",
                        headers={"Content-Disposition": f"attachment; filename={filename}"})

    @app.route("/reports/export/records.csv")
    @login_required
    def export_records():
        rows = db.query(
            "SELECT r.id, r.title, r.category, r.status, r.priority, COALESCE(u.full_name,'Unassigned'), "
            "r.description, r.created_at, r.updated_at FROM system_records r "
            "LEFT JOIN users u ON u.id = r.assigned_user_id ORDER BY r.id")
        log("Export", "Report", "Exported records to CSV")
        return csv_response("system_records.csv",
                            ["ID", "Title", "Category", "Status", "Priority", "Assigned To", "Description",
                             "Created At", "Updated At"], [list(r) for r in rows])

    @app.route("/reports/export/users.csv")
    @login_required
    def export_users():
        rows = db.query("SELECT id, full_name, email, phone, role, department, status, created_at FROM users ORDER BY id")
        log("Export", "Report", "Exported users to CSV")
        return csv_response("users.csv",
                            ["ID", "Full Name", "Email", "Phone", "Role", "Department", "Status", "Created At"],
                            [list(r) for r in rows])

    # ----------------------------------------------------- settings
    @app.route("/settings")
    @login_required
    def settings():
        return render_template("settings.html", errors={}, form={}, tab=request.args.get("tab", "profile"),
                               sysset={
                                   "system_name": db.get_setting("system_name"),
                                   "organization": db.get_setting("organization"),
                                   "contact_email": db.get_setting("contact_email"),
                                   "items_per_page": db.get_setting("items_per_page", "8"),
                               })

    def settings_page(tab, errors, form):
        return render_template("settings.html", errors=errors, form=form, tab=tab, sysset={
            "system_name": db.get_setting("system_name"), "organization": db.get_setting("organization"),
            "contact_email": db.get_setting("contact_email"),
            "items_per_page": db.get_setting("items_per_page", "8")})

    @app.route("/settings/profile", methods=["POST"])
    @login_required
    def settings_profile():
        form = {"full_name": request.form.get("full_name", "").strip(),
                "email": request.form.get("email", "").strip().lower()}
        errors = {}
        if not 2 <= len(form["full_name"]) <= 80:
            errors["full_name"] = "Full name must be 2 to 80 characters."
        if not EMAIL_RE.match(form["email"]):
            errors["email"] = "Enter a valid email address."
        elif db.query("SELECT id FROM admin WHERE email = ? AND id != ?", (form["email"], g.admin["id"]), one=True):
            errors["email"] = "This email is used by another account."
        if errors:
            flash("Please correct the errors below.", "danger")
            return settings_page("profile", errors, form), 200
        db.execute("UPDATE admin SET full_name = ?, email = ? WHERE id = ?",
                   (form["full_name"], form["email"], g.admin["id"]))
        log("Update", "Profile", "Updated admin profile")
        flash("Profile updated.", "success")
        return redirect(url_for("settings", tab="profile"))

    @app.route("/settings/password", methods=["POST"])
    @login_required
    def settings_password():
        current = request.form.get("current_password", "")
        new = request.form.get("new_password", "")
        confirm = request.form.get("confirm_password", "")
        errors = {}
        if not check_password_hash(g.admin["password_hash"], current):
            errors["current_password"] = "Current password is incorrect."
        if len(new) < 8 or not re.search(r"[A-Za-z]", new) or not re.search(r"\d", new):
            errors["new_password"] = "New password must be at least 8 characters with letters and numbers."
        elif new == current:
            errors["new_password"] = "New password must be different from the current one."
        if new != confirm:
            errors["confirm_password"] = "Passwords do not match."
        if errors:
            flash("Password was not changed. Please correct the errors.", "danger")
            return settings_page("password", errors, {}), 200
        db.execute("UPDATE admin SET password_hash = ? WHERE id = ?", (generate_password_hash(new), g.admin["id"]))
        log("Update", "Security", "Administrator changed password")
        flash("Password changed successfully.", "success")
        return redirect(url_for("settings", tab="password"))

    @app.route("/settings/system", methods=["POST"])
    @login_required
    def settings_system():
        form = {k: request.form.get(k, "").strip()
                for k in ("system_name", "organization", "contact_email", "items_per_page")}
        errors = {}
        if not 3 <= len(form["system_name"]) <= 60:
            errors["system_name"] = "System name must be 3 to 60 characters."
        if not 2 <= len(form["organization"]) <= 80:
            errors["organization"] = "Organization must be 2 to 80 characters."
        if not EMAIL_RE.match(form["contact_email"]):
            errors["contact_email"] = "Enter a valid email address."
        if not form["items_per_page"].isdigit() or not 3 <= int(form["items_per_page"]) <= 50:
            errors["items_per_page"] = "Items per page must be a number from 3 to 50."
        if errors:
            flash("Please correct the errors below.", "danger")
            resp = render_template("settings.html", errors=errors, form=form, tab="system", sysset=form)
            return resp, 200
        for k, v in form.items():
            db.set_setting(k, v)
        log("Update", "Settings", "Updated system settings")
        flash("System settings saved.", "success")
        return redirect(url_for("settings", tab="system"))

    return app


app = create_app()

if __name__ == "__main__":
    app.run(host="127.0.0.1", port=5000, debug=True)
