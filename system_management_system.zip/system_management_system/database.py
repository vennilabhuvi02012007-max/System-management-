"""Database helpers: connection handling, initialisation and sample data."""
import os
import sqlite3
from datetime import datetime, timedelta

from flask import current_app, g
from werkzeug.security import generate_password_hash


# ---------------------------------------------------------------- connection
def get_db():
    """Return a per-request SQLite connection."""
    if "db" not in g:
        g.db = sqlite3.connect(current_app.config["DATABASE"])
        g.db.row_factory = sqlite3.Row
        g.db.execute("PRAGMA foreign_keys = ON")
    return g.db


def close_db(exception=None):
    db = g.pop("db", None)
    if db is not None:
        db.close()


def query(sql, args=(), one=False):
    """Run a SELECT and return rows (or a single row when one=True)."""
    cur = get_db().execute(sql, args)
    rows = cur.fetchall()
    cur.close()
    if one:
        return rows[0] if rows else None
    return rows


def execute(sql, args=()):
    """Run INSERT/UPDATE/DELETE, commit, and return the last row id."""
    db = get_db()
    cur = db.execute(sql, args)
    db.commit()
    return cur.lastrowid


def log_activity(admin_id, action, entity, details=""):
    """Store an administrator action in the activity log."""
    execute(
        "INSERT INTO activity_logs (admin_id, action, entity, details, created_at) VALUES (?,?,?,?,?)",
        (admin_id, action, entity, details, datetime.now().strftime("%Y-%m-%d %H:%M:%S")),
    )


def get_setting(key, default=""):
    row = query("SELECT value FROM settings WHERE key = ?", (key,), one=True)
    return row["value"] if row else default


def set_setting(key, value):
    execute(
        "INSERT INTO settings (key, value) VALUES (?, ?) "
        "ON CONFLICT(key) DO UPDATE SET value = excluded.value",
        (key, str(value)),
    )


# ------------------------------------------------------------ initialisation
def init_db(app):
    """Create tables (if missing) and load default / sample data on first run."""
    db_path = app.config["DATABASE"]
    os.makedirs(os.path.dirname(db_path), exist_ok=True)

    conn = sqlite3.connect(db_path)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    with open(app.config["SCHEMA_FILE"], "r", encoding="utf-8") as f:
        conn.executescript(f.read())

    has_admin = conn.execute("SELECT COUNT(*) FROM admin").fetchone()[0]
    if not has_admin:
        _seed(conn, app.config)
    conn.close()


def _ts(days_ago=0, hours_ago=0):
    return (datetime.now() - timedelta(days=days_ago, hours=hours_ago)).strftime("%Y-%m-%d %H:%M:%S")


def _seed(conn, cfg):
    conn.execute(
        "INSERT INTO admin (username, full_name, email, password_hash, created_at) VALUES (?,?,?,?,?)",
        (
            cfg["DEFAULT_ADMIN_USERNAME"],
            cfg["DEFAULT_ADMIN_NAME"],
            cfg["DEFAULT_ADMIN_EMAIL"],
            generate_password_hash(cfg["DEFAULT_ADMIN_PASSWORD"]),
            _ts(60),
        ),
    )
    default_settings = {
        "system_name": "System Management System",
        "organization": "ABC College of Engineering",
        "contact_email": "support@abccollege.edu",
        "items_per_page": "8",
        "maintenance_mode": "off",
    }
    conn.executemany("INSERT INTO settings (key, value) VALUES (?,?)", default_settings.items())

    if cfg.get("LOAD_SAMPLE_DATA"):
        users = [
            ("Aarav Sharma", "aarav.sharma@example.com", "9876543210", "Manager", "Computer Science", "Active", 55),
            ("Priya Nair", "priya.nair@example.com", "9876501234", "Staff", "Administration", "Active", 50),
            ("Rohan Mehta", "rohan.mehta@example.com", "9812345678", "Student", "Information Technology", "Active", 45),
            ("Sneha Iyer", "sneha.iyer@example.com", "9823456789", "Student", "Electronics", "Inactive", 40),
            ("Karthik Raja", "karthik.raja@example.com", "9834567890", "Staff", "Network Operations", "Active", 38),
            ("Divya Menon", "divya.menon@example.com", "9845678901", "Manager", "Finance", "Active", 30),
            ("Arjun Das", "arjun.das@example.com", "9856789012", "Guest", "Visitors", "Suspended", 25),
            ("Meera Krishnan", "meera.krishnan@example.com", "9867890123", "Student", "Computer Science", "Active", 20),
            ("Vikram Singh", "vikram.singh@example.com", "9878901234", "Staff", "Maintenance", "Active", 15),
            ("Lakshmi Pillai", "lakshmi.pillai@example.com", "9889012345", "Staff", "Library", "Inactive", 10),
            ("Nikhil Verma", "nikhil.verma@example.com", "9890123456", "Student", "Mechanical", "Active", 6),
            ("Ananya Roy", "ananya.roy@example.com", "9801234567", "Guest", "Visitors", "Active", 2),
        ]
        conn.executemany(
            "INSERT INTO users (full_name, email, phone, role, department, status, created_at) VALUES (?,?,?,?,?,?,?)",
            [(n, e, p, r, d, s, _ts(a)) for n, e, p, r, d, s, a in users],
        )

        records = [
            ("Replace faulty lab switch", "Network", "Core switch in Lab 3 drops packets.", "In Progress", "High", 5, 20),
            ("Install Python 3.12 on lab PCs", "Software", "Upgrade all CS lab machines.", "Completed", "Medium", 1, 28),
            ("Quarterly firewall audit", "Security", "Review firewall rules and logs.", "Open", "High", 5, 4),
            ("Projector maintenance - Room 204", "Hardware", "Lamp replacement and cleaning.", "Open", "Low", 9, 3),
            ("Library server backup check", "Maintenance", "Verify nightly backups restore correctly.", "Completed", "Medium", 10, 26),
            ("Update antivirus definitions", "Security", "Push latest definitions to all nodes.", "Completed", "Medium", 5, 18),
            ("Wi-Fi coverage survey", "Network", "Survey dead zones in hostel block.", "In Progress", "Medium", 5, 12),
            ("Replace UPS batteries", "Hardware", "UPS in server room at 40% health.", "Open", "High", 9, 7),
            ("Migrate student portal database", "Software", "Move portal DB to new server.", "In Progress", "High", 1, 9),
            ("Archive 2023 exam records", "Other", "Move old exam data to cold storage.", "Archived", "Low", 2, 50),
            ("Set up CCTV monitoring", "Security", "Install and configure 8 cameras.", "Completed", "High", 9, 35),
            ("Printer driver rollout", "Software", "Deploy new drivers to admin office.", "Completed", "Low", 2, 22),
            ("Cable management - server room", "Maintenance", "Re-label and tidy rack cabling.", "Open", "Low", 9, 2),
            ("Upgrade RAM on lab servers", "Hardware", "Increase from 16 GB to 32 GB.", "In Progress", "Medium", 5, 5),
            ("Review user access policy", "Security", "Annual review of roles and permissions.", "Open", "Medium", 6, 1),
        ]
        conn.executemany(
            "INSERT INTO system_records (title, category, description, status, priority, assigned_user_id, created_by, created_at, updated_at) "
            "VALUES (?,?,?,?,?,?,1,?,?)",
            [(t, c, d, s, p, u, _ts(a), _ts(a)) for t, c, d, s, p, u, a in records],
        )

        logs = [
            ("Login", "Session", "Administrator signed in", 6, 0),
            ("Create", "User", "Added user 'Ananya Roy'", 2, 0),
            ("Create", "Record", "Added record 'Review user access policy'", 1, 0),
            ("Update", "Record", "Updated record 'Wi-Fi coverage survey'", 1, 5),
            ("Update", "User", "Changed status of 'Arjun Das' to Suspended", 3, 2),
            ("Delete", "Record", "Deleted record 'Old test entry'", 4, 1),
            ("Update", "Settings", "Updated system settings", 5, 3),
            ("Export", "Report", "Exported records to CSV", 2, 6),
            ("Login", "Session", "Administrator signed in", 0, 5),
        ]
        conn.executemany(
            "INSERT INTO activity_logs (admin_id, action, entity, details, created_at) VALUES (1,?,?,?,?)",
            [(a, e, d, _ts(days, hrs)) for a, e, d, days, hrs in logs],
        )
    conn.commit()
