"""Application configuration for the System Management System."""
import os

BASE_DIR = os.path.abspath(os.path.dirname(__file__))


class Config:
    # Change SECRET_KEY in production (set the SMS_SECRET_KEY environment variable).
    SECRET_KEY = os.environ.get("SMS_SECRET_KEY", "dev-secret-key-change-me-in-production")
    DATABASE = os.path.join(BASE_DIR, "database", "sms.db")
    SCHEMA_FILE = os.path.join(BASE_DIR, "database", "schema.sql")

    # Session / cookie security
    SESSION_COOKIE_HTTPONLY = True
    SESSION_COOKIE_SAMESITE = "Lax"
    PERMANENT_SESSION_LIFETIME = 60 * 60 * 2  # 2 hours

    # CSRF protection (disable only in automated tests)
    CSRF_ENABLED = True

    # Default admin account created on first run
    DEFAULT_ADMIN_USERNAME = "admin"
    DEFAULT_ADMIN_PASSWORD = "Admin@123"
    DEFAULT_ADMIN_NAME = "System Administrator"
    DEFAULT_ADMIN_EMAIL = "admin@example.com"

    # Load demonstration data when the database is created
    LOAD_SAMPLE_DATA = True


class TestConfig(Config):
    TESTING = True
    CSRF_ENABLED = False
    LOAD_SAMPLE_DATA = True
