-- System Management System : database schema (SQLite)
PRAGMA foreign_keys = ON;

CREATE TABLE IF NOT EXISTS admin (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    username      TEXT    NOT NULL UNIQUE,
    full_name     TEXT    NOT NULL,
    email         TEXT    NOT NULL UNIQUE,
    password_hash TEXT    NOT NULL,
    created_at    TEXT    NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS users (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    full_name   TEXT NOT NULL,
    email       TEXT NOT NULL UNIQUE,
    phone       TEXT,
    role        TEXT NOT NULL DEFAULT 'Staff'
                CHECK (role IN ('Manager','Staff','Student','Guest')),
    department  TEXT,
    status      TEXT NOT NULL DEFAULT 'Active'
                CHECK (status IN ('Active','Inactive','Suspended')),
    created_at  TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS system_records (
    id               INTEGER PRIMARY KEY AUTOINCREMENT,
    title            TEXT NOT NULL,
    category         TEXT NOT NULL
                     CHECK (category IN ('Hardware','Software','Network','Security','Maintenance','Other')),
    description      TEXT,
    status           TEXT NOT NULL DEFAULT 'Open'
                     CHECK (status IN ('Open','In Progress','Completed','Archived')),
    priority         TEXT NOT NULL DEFAULT 'Medium'
                     CHECK (priority IN ('Low','Medium','High')),
    assigned_user_id INTEGER,
    created_by       INTEGER,
    created_at       TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at       TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (assigned_user_id) REFERENCES users(id) ON DELETE SET NULL,
    FOREIGN KEY (created_by)       REFERENCES admin(id) ON DELETE SET NULL
);

CREATE TABLE IF NOT EXISTS activity_logs (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    admin_id   INTEGER,
    action     TEXT NOT NULL,
    entity     TEXT NOT NULL,
    details    TEXT,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (admin_id) REFERENCES admin(id) ON DELETE SET NULL
);

CREATE TABLE IF NOT EXISTS settings (
    key   TEXT PRIMARY KEY,
    value TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_users_status    ON users(status);
CREATE INDEX IF NOT EXISTS idx_records_status  ON system_records(status);
CREATE INDEX IF NOT EXISTS idx_records_cat     ON system_records(category);
CREATE INDEX IF NOT EXISTS idx_logs_created    ON activity_logs(created_at);
