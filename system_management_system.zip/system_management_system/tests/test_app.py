"""Automated tests for the System Management System.

Run from the project root:   python -m unittest discover -s tests -v
"""
import os
import sqlite3
import sys
import tempfile
import unittest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from app import create_app          # noqa: E402
from config import TestConfig       # noqa: E402


class BaseTestCase(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.NamedTemporaryFile(suffix=".db", delete=False)
        self.tmp.close()

        class Cfg(TestConfig):
            DATABASE = self.tmp.name

        self.app = create_app(Cfg)
        self.client = self.app.test_client()

    def tearDown(self):
        os.unlink(self.tmp.name)

    def login(self, username="admin", password="Admin@123"):
        return self.client.post("/login", data={"username": username, "password": password},
                                follow_redirects=True)

    def query(self, sql, args=()):
        conn = sqlite3.connect(self.tmp.name)
        conn.row_factory = sqlite3.Row
        rows = conn.execute(sql, args).fetchall()
        conn.close()
        return rows


class LoginTests(BaseTestCase):
    def test_login_page_loads(self):
        self.assertEqual(self.client.get("/login").status_code, 200)

    def test_valid_login(self):
        r = self.login()
        self.assertIn(b"Dashboard", r.data)
        self.assertIn(b"Total Users", r.data)

    def test_wrong_password(self):
        r = self.login(password="wrong")
        self.assertIn(b"Invalid username or password", r.data)

    def test_unknown_user(self):
        self.assertIn(b"Invalid username or password", self.login(username="nobody").data)

    def test_empty_fields_validation(self):
        r = self.client.post("/login", data={"username": "", "password": ""})
        self.assertIn(b"Username is required", r.data)
        self.assertIn(b"Password is required", r.data)

    def test_protected_pages_redirect_to_login(self):
        for url in ("/dashboard", "/users", "/records", "/activities", "/reports", "/settings"):
            r = self.client.get(url)
            self.assertEqual(r.status_code, 302, url)
            self.assertIn("/login", r.headers["Location"])

    def test_logout(self):
        self.login()
        r = self.client.post("/logout", follow_redirects=True)
        self.assertIn(b"logged out", r.data)
        self.assertEqual(self.client.get("/dashboard").status_code, 302)

    def test_open_redirect_blocked(self):
        r = self.client.post("/login?next=//evil.com", data={"username": "admin", "password": "Admin@123"})
        self.assertNotIn("evil.com", r.headers["Location"])


class DatabaseTests(BaseTestCase):
    def test_tables_exist(self):
        names = {r["name"] for r in self.query("SELECT name FROM sqlite_master WHERE type='table'")}
        for t in ("admin", "users", "system_records", "activity_logs", "settings"):
            self.assertIn(t, names)

    def test_password_is_hashed(self):
        pw = self.query("SELECT password_hash FROM admin WHERE username='admin'")[0][0]
        self.assertNotEqual(pw, "Admin@123")
        self.assertTrue(pw.startswith(("scrypt:", "pbkdf2:")))

    def test_sample_data_loaded(self):
        self.assertGreaterEqual(self.query("SELECT COUNT(*) FROM users")[0][0], 10)
        self.assertGreaterEqual(self.query("SELECT COUNT(*) FROM system_records")[0][0], 10)

    def test_unique_email_constraint(self):
        conn = sqlite3.connect(self.tmp.name)
        with self.assertRaises(sqlite3.IntegrityError):
            conn.execute("INSERT INTO users (full_name, email) VALUES ('X', 'aarav.sharma@example.com')")
        conn.close()


class UserCrudTests(BaseTestCase):
    def setUp(self):
        super().setUp()
        self.login()

    def good_user(self, **over):
        d = {"full_name": "Test Person", "email": "test.person@example.com", "phone": "9999999999",
             "role": "Staff", "department": "QA", "status": "Active"}
        d.update(over)
        return d

    def test_list_users(self):
        r = self.client.get("/users")
        self.assertEqual(r.status_code, 200)
        self.assertIn(b"Add User", r.data)

    def test_create_user(self):
        r = self.client.post("/users/add", data=self.good_user(), follow_redirects=True)
        self.assertIn(b"User added successfully", r.data)
        self.assertEqual(len(self.query("SELECT * FROM users WHERE email='test.person@example.com'")), 1)

    def test_create_user_logs_activity(self):
        self.client.post("/users/add", data=self.good_user())
        self.assertEqual(len(self.query("SELECT * FROM activity_logs WHERE details LIKE '%Test Person%'")), 1)

    def test_duplicate_email_rejected(self):
        self.client.post("/users/add", data=self.good_user())
        r = self.client.post("/users/add", data=self.good_user())
        self.assertIn(b"already registered", r.data)

    def test_validation_errors(self):
        r = self.client.post("/users/add", data=self.good_user(full_name="A", email="bad", phone="abc", role=""))
        for msg in (b"Full name must be", b"valid email", b"Phone must be", b"valid role"):
            self.assertIn(msg, r.data)

    def test_edit_user(self):
        self.client.post("/users/add", data=self.good_user())
        uid = self.query("SELECT id FROM users WHERE email='test.person@example.com'")[0][0]
        r = self.client.post(f"/users/{uid}/edit", data=self.good_user(full_name="Changed Name"), follow_redirects=True)
        self.assertIn(b"User updated successfully", r.data)
        self.assertEqual(self.query("SELECT full_name FROM users WHERE id=?", (uid,))[0][0], "Changed Name")

    def test_edit_missing_user_404(self):
        self.assertEqual(self.client.get("/users/9999/edit").status_code, 404)

    def test_toggle_status(self):
        uid = self.query("SELECT id FROM users WHERE status='Active' LIMIT 1")[0][0]
        self.client.post(f"/users/{uid}/status", data={"status": "Suspended"})
        self.assertEqual(self.query("SELECT status FROM users WHERE id=?", (uid,))[0][0], "Suspended")

    def test_delete_user(self):
        self.client.post("/users/add", data=self.good_user())
        uid = self.query("SELECT id FROM users WHERE email='test.person@example.com'")[0][0]
        r = self.client.post(f"/users/{uid}/delete", follow_redirects=True)
        self.assertIn(b"User deleted", r.data)
        self.assertEqual(len(self.query("SELECT * FROM users WHERE id=?", (uid,))), 0)

    def test_delete_user_keeps_records(self):
        before = self.query("SELECT COUNT(*) FROM system_records")[0][0]
        self.client.post("/users/5/delete")  # assigned to several records
        self.assertEqual(self.query("SELECT COUNT(*) FROM system_records")[0][0], before)

    def test_search_and_filter(self):
        r = self.client.get("/users?q=priya")
        self.assertIn(b"Priya Nair", r.data)
        self.assertNotIn(b"Rohan Mehta", r.data)
        r = self.client.get("/users?status=Suspended")
        self.assertIn(b"Arjun Das", r.data)

    def test_pagination(self):
        r = self.client.get("/users?page=2")
        self.assertEqual(r.status_code, 200)
        self.assertEqual(self.client.get("/users?page=abc").status_code, 200)


class RecordCrudTests(BaseTestCase):
    def setUp(self):
        super().setUp()
        self.login()

    def good(self, **over):
        d = {"title": "New test record", "category": "Software", "description": "desc",
             "status": "Open", "priority": "High", "assigned_user_id": "1"}
        d.update(over)
        return d

    def test_create_record(self):
        r = self.client.post("/records/add", data=self.good(), follow_redirects=True)
        self.assertIn(b"Record created successfully", r.data)

    def test_record_validation(self):
        r = self.client.post("/records/add", data=self.good(title="ab", category="Bad", assigned_user_id="9999"))
        self.assertIn(b"Title must be", r.data)
        self.assertIn(b"valid category", r.data)
        self.assertIn(b"does not exist", r.data)

    def test_update_record(self):
        self.client.post("/records/add", data=self.good())
        rid = self.query("SELECT id FROM system_records WHERE title='New test record'")[0][0]
        r = self.client.post(f"/records/{rid}/edit", data=self.good(status="Completed"), follow_redirects=True)
        self.assertIn(b"Record updated successfully", r.data)
        self.assertEqual(self.query("SELECT status FROM system_records WHERE id=?", (rid,))[0][0], "Completed")

    def test_view_record(self):
        self.assertEqual(self.client.get("/records/1").status_code, 200)
        self.assertEqual(self.client.get("/records/9999").status_code, 404)

    def test_delete_record(self):
        self.client.post("/records/add", data=self.good())
        rid = self.query("SELECT id FROM system_records WHERE title='New test record'")[0][0]
        self.client.post(f"/records/{rid}/delete")
        self.assertEqual(len(self.query("SELECT * FROM system_records WHERE id=?", (rid,))), 0)

    def test_search_and_filter(self):
        r = self.client.get("/records?category=Security&status=Open")
        self.assertIn(b"Quarterly firewall audit", r.data)
        self.assertNotIn(b"Install Python", r.data)


class ReportsSettingsTests(BaseTestCase):
    def setUp(self):
        super().setUp()
        self.login()

    def test_dashboard_and_pages_render(self):
        for url in ("/dashboard", "/activities", "/reports", "/settings", "/users/add", "/records/add"):
            self.assertEqual(self.client.get(url).status_code, 200, url)

    def test_csv_export(self):
        r = self.client.get("/reports/export/records.csv")
        self.assertEqual(r.status_code, 200)
        self.assertIn("text/csv", r.headers["Content-Type"])
        self.assertTrue(r.data.startswith(b"ID,Title,Category"))
        r = self.client.get("/reports/export/users.csv")
        self.assertTrue(r.data.startswith(b"ID,Full Name"))

    def test_change_password_success(self):
        r = self.client.post("/settings/password", data={
            "current_password": "Admin@123", "new_password": "NewPass123", "confirm_password": "NewPass123"},
            follow_redirects=True)
        self.assertIn(b"Password changed successfully", r.data)
        self.client.post("/logout")
        self.assertIn(b"Dashboard", self.login(password="NewPass123").data)

    def test_change_password_validation(self):
        r = self.client.post("/settings/password", data={
            "current_password": "bad", "new_password": "short", "confirm_password": "other"})
        self.assertIn(b"Current password is incorrect", r.data)
        self.assertIn(b"at least 8 characters", r.data)
        self.assertIn(b"do not match", r.data)

    def test_update_profile(self):
        self.client.post("/settings/profile", data={"full_name": "New Admin", "email": "new@example.com"})
        self.assertEqual(self.query("SELECT full_name FROM admin")[0][0], "New Admin")

    def test_profile_validation(self):
        r = self.client.post("/settings/profile", data={"full_name": "", "email": "nope"})
        self.assertIn(b"Full name must be", r.data)

    def test_system_settings(self):
        self.client.post("/settings/system", data={
            "system_name": "My Portal", "organization": "XYZ College",
            "contact_email": "a@b.com", "items_per_page": "5"})
        r = self.client.get("/dashboard")
        self.assertIn(b"My Portal", r.data)

    def test_system_settings_validation(self):
        r = self.client.post("/settings/system", data={
            "system_name": "", "organization": "", "contact_email": "x", "items_per_page": "500"})
        self.assertIn(b"System name must be", r.data)
        self.assertIn(b"Items per page must be", r.data)

    def test_unknown_page_404(self):
        self.assertEqual(self.client.get("/nope").status_code, 404)


class CsrfTests(unittest.TestCase):
    def test_post_without_token_rejected(self):
        tmp = tempfile.NamedTemporaryFile(suffix=".db", delete=False)
        tmp.close()

        class Cfg(TestConfig):
            DATABASE = tmp.name
            CSRF_ENABLED = True

        client = create_app(Cfg).test_client()
        r = client.post("/login", data={"username": "admin", "password": "Admin@123"})
        self.assertEqual(r.status_code, 400)
        os.unlink(tmp.name)


if __name__ == "__main__":
    unittest.main(verbosity=2)
