# System Management System

A web-based administration dashboard for managing users, system records, activities and reports.
Built as a college-level full-stack project with **Flask**, **SQLite**, **Bootstrap 5** and **Chart.js**.

---

## 1. Project Introduction
The System Management System (SMS) gives an administrator one central place to manage the people and
assets of an organisation (for example a college IT department). The administrator can sign in securely,
view live statistics, manage users and system records, review an audit trail of every action, generate
reports and configure the system.

## 2. Project Objectives
- Provide a secure, session-based administrator login.
- Centralise user and record management with full CRUD operations.
- Track every important administrator action in an activity log.
- Present live statistics through summary cards and interactive charts.
- Generate printable reports and CSV exports.
- Keep the code simple, well-structured and easy to demonstrate.

## 3. Features
| Module | Features |
|---|---|
| **Login** | Admin login, hashed passwords, session management, logout, input validation, CSRF protection |
| **Dashboard** | Summary cards, 4 interactive charts, recent activity feed, responsive sidebar |
| **Users** | Add / view / edit / delete (with confirmation modal), search, filter by role & status, activate/deactivate toggle, pagination |
| **System Records** | Create / view / update / delete, search, filter by category & status, assign to users, priority |
| **Activities** | Automatic audit log of logins, creates, updates, deletes, exports; search and filter |
| **Reports** | Summary statistics, CSV export (records, users), print-friendly report |
| **Settings** | Admin profile, change password, system settings (name, organisation, page size) |

## 4. Technologies Used
- **Frontend:** HTML5, CSS3, JavaScript, Bootstrap 5.3
- **Backend:** Python 3 + Flask
- **Database:** SQLite (via Python's built-in `sqlite3`)
- **Charts:** Chart.js 4
- **Icons:** Font Awesome 6
- Bootstrap, Chart.js and Font Awesome load from CDNs, so an internet connection is needed in the browser.

## 5. Software Requirements
- Python 3.9 or newer
- pip (Python package manager)
- A modern web browser (Chrome, Edge, Firefox, Safari)
- Any code editor (VS Code recommended)

## 6. Project Folder Structure
```
system_management_system/
├── app.py                  # Flask application (routes, validation, business logic)
├── config.py               # Configuration classes
├── database.py             # DB connection helpers, initialisation, sample data
├── requirements.txt        # Python dependencies
├── README.md               # This file
├── .gitignore
├── database/
│   ├── schema.sql          # Table definitions
│   └── sms.db              # Created automatically on first run
├── templates/
│   ├── _macros.html        # Reusable badges, pagination, delete modal
│   ├── base.html           # Layout: sidebar + top bar
│   ├── login.html
│   ├── dashboard.html
│   ├── users.html / user_form.html
│   ├── records.html / record_form.html / record_view.html
│   ├── activities.html
│   ├── reports.html
│   ├── settings.html
│   └── error.html
├── static/
│   ├── css/style.css
│   ├── js/main.js          # Sidebar, delete modal, form validation
│   ├── js/charts.js        # Dashboard charts
│   └── images/logo.svg
├── tests/
│   ├── __init__.py
│   └── test_app.py         # 40 automated tests
└── docs/
    ├── PROJECT_REPORT.md   # Abstract, introduction, modules, conclusion ...
    └── screenshots/
```

## 7. Installation Instructions
```bash
# 1. Open a terminal inside the project folder
cd system_management_system

# 2. (Recommended) create and activate a virtual environment
python -m venv venv
venv\Scripts\activate          # Windows
source venv/bin/activate       # macOS / Linux

# 3. Install dependencies
pip install -r requirements.txt
```

## 8. How to Run the Project
```bash
python app.py
```
Open **http://127.0.0.1:5000** in your browser.

Run the automated tests:
```bash
python -m unittest discover -s tests -v
```

## 9. Database Setup
No manual setup is needed. On first start, `database.py` reads `database/schema.sql`, creates
`database/sms.db`, adds the default administrator and loads demonstration data
(12 users, 15 records, 9 activity entries).
To reset the database, stop the server, delete `database/sms.db` and start again.

**Tables**

| Table | Purpose | Key columns |
|---|---|---|
| `admin` | Administrator accounts | username, email, password_hash |
| `users` | People managed by the system | full_name, email (unique), role, status |
| `system_records` | System records / tickets | title, category, status, priority, assigned_user_id → users, created_by → admin |
| `activity_logs` | Audit trail | admin_id → admin, action, entity, details |
| `settings` | Key/value system settings | key, value |

**Relationships:** `system_records.assigned_user_id → users.id` (ON DELETE SET NULL),
`system_records.created_by → admin.id` (SET NULL), `activity_logs.admin_id → admin.id` (SET NULL).

## 10. Demo Login Credentials
| Username | Password |
|---|---|
| `admin` | `Admin@123` |

Change the password after first login (Settings → Change Password).

## 11. Screenshots
Run the app and save your own screenshots into `docs/screenshots/`, then reference them here:

| Page | File |
|---|---|
| Login | `docs/screenshots/login.png` |
| Dashboard | `docs/screenshots/dashboard.png` |
| User Management | `docs/screenshots/users.png` |
| System Records | `docs/screenshots/records.png` |
| Reports | `docs/screenshots/reports.png` |
| Settings | `docs/screenshots/settings.png` |

Markdown to embed: `![Dashboard](docs/screenshots/dashboard.png)`

## 12. Security Notes
- Passwords are stored using Werkzeug's salted hash (`generate_password_hash`).
- Every POST form carries a CSRF token; all SQL uses parameterised queries; Jinja2 auto-escapes output.
- For any real deployment set the `SMS_SECRET_KEY` environment variable and disable `debug`.

## 13. Future Enhancements
- Multiple admin accounts with role-based permissions
- Email notifications and password reset by email
- File attachments for records
- REST API with token authentication
- Dark mode and multi-language support
- Migration to PostgreSQL / MySQL for production
- Login attempt throttling and two-factor authentication

## Troubleshooting
| Problem | Solution |
|---|---|
| `ModuleNotFoundError: flask` | Activate the virtual environment and run `pip install -r requirements.txt` |
| Port 5000 in use | Change `port=5000` at the bottom of `app.py` |
| Page looks unstyled | Check your internet connection (CDN assets) |
| Forgot admin password | Delete `database/sms.db` and restart to recreate defaults |
