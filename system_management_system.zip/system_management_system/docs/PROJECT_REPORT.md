# System Management System - Project Report

## 1. Abstract
The System Management System is a web-based application that lets an administrator manage users, system
records, activities and reports from a single dashboard. It is built with Flask (Python), SQLite,
Bootstrap 5, Chart.js and Font Awesome. The system provides secure login with hashed passwords and
sessions, full create-read-update-delete operations on users and records, an automatic audit log of
administrator actions, statistical reports with CSV export and printing, and configurable settings.
The application is lightweight, responsive and easy to deploy, making it suitable for small organisations
such as colleges, laboratories and IT departments.

## 2. Introduction
Organisations keep large amounts of information about their users and the systems they maintain.
Managing this information on paper or in scattered spreadsheets leads to duplication, errors and delays.
A centralised management system reduces these problems by storing data in one database and presenting it
through an easy interface. This project implements such a system as a three-layer web application:
presentation (HTML/CSS/JavaScript/Bootstrap), application logic (Flask) and data (SQLite).

## 3. Existing System
- Records are maintained manually in registers or in separate spreadsheets.
- No central login or access control; files can be edited by anyone.
- No audit trail showing who changed what and when.
- Searching and filtering is slow; duplicates and inconsistencies are common.
- Reports must be prepared by hand and take considerable time.
- No visual overview (charts) of the current state of the system.

## 4. Proposed System
- A secure web application with administrator authentication and session control.
- A single SQLite database with validated, structured data and unique constraints.
- Dashboard with live counts, charts and a recent-activity feed.
- Instant search, filters and pagination for users, records and activities.
- Automatic activity logging of every important action.
- One-click CSV export and print-ready summary report.
- Responsive interface that works on desktop, tablet and mobile.

**Advantages:** faster operations, fewer errors, accountability, easy reporting, no cost, simple deployment.

## 5. System Requirements
### Functional requirements
1. The administrator can log in and log out.
2. The administrator can add, view, edit, delete, search and filter users.
3. The administrator can change a user's status.
4. The administrator can create, view, update, delete, search and filter records.
5. The system logs administrator actions automatically.
6. The system displays statistics and charts, exports CSV and prints reports.
7. The administrator can update the profile, password and system settings.

### Non-functional requirements
- **Security:** hashed passwords, CSRF tokens, parameterised SQL, session timeout.
- **Usability:** clean responsive layout, clear validation messages.
- **Performance:** pages respond in under a second for thousands of records.
- **Portability:** runs on Windows, Linux and macOS.
- **Maintainability:** modular code with a clear folder structure and automated tests.

## 6. Software and Hardware Requirements
### Software
| Item | Requirement |
|---|---|
| Operating system | Windows 10/11, Ubuntu 20.04+, or macOS |
| Language | Python 3.9+ |
| Framework | Flask 3.x |
| Database | SQLite 3 (bundled with Python) |
| Browser | Chrome / Edge / Firefox (latest) |
| Frontend libraries | Bootstrap 5.3, Chart.js 4, Font Awesome 6 (CDN) |
| Editor | VS Code / PyCharm |

### Hardware (minimum)
| Item | Requirement |
|---|---|
| Processor | Dual-core 1.6 GHz or better |
| RAM | 2 GB (4 GB recommended) |
| Storage | 200 MB free space |
| Network | Internet access for CDN assets (browser side) |

## 7. Modules Description
1. **Authentication module** - login form, password verification with hashes, session creation, logout, protection of all pages with a `login_required` decorator, CSRF validation.
2. **Dashboard module** - total users, active users, total and open records, doughnut / bar / pie / line charts, recent activities.
3. **User management module** - CRUD for users, unique email validation, role and status, search, filters, pagination, delete confirmation, quick activate/deactivate.
4. **System records module** - CRUD for records with category, priority, status and assignment to a user; search and filters.
5. **Activity management module** - every login, create, update, delete and export is saved with the administrator, entity, details and time; viewable with search and filter.
6. **Reports module** - statistics by status, role, category and priority; completion rate; CSV export; print layout.
7. **Settings module** - edit admin profile, change password (strength rules), and system settings such as system name, organisation and items per page.

### Database design
`admin` (1) — (N) `system_records` via `created_by`; `users` (1) — (N) `system_records` via `assigned_user_id`;
`admin` (1) — (N) `activity_logs`; `settings` is a key-value table.

## 8. Testing Summary
The project contains 40 automated tests (`tests/test_app.py`) covering:

| Area | Sample test cases |
|---|---|
| Login | valid login; wrong password; unknown user; empty fields; redirect when not logged in; logout; open-redirect blocked |
| Database | all tables exist; password stored hashed; sample data loaded; unique email constraint |
| User CRUD | create; duplicate email; edit; delete; status change; search and filter; pagination; 404 for missing user |
| Record CRUD | create; update; view; delete; filters |
| Form validation | name length, e-mail format, phone format, role required, title length, category, password rules, settings ranges |
| Reports / Settings | CSV export content type and header; profile update; password change; system settings |
| Security | POST without CSRF token returns HTTP 400 |

### Manual test cases
| ID | Test | Steps | Expected result |
|---|---|---|---|
| TC-01 | Valid login | Enter admin / Admin@123 | Dashboard opens |
| TC-02 | Invalid login | Enter wrong password | "Invalid username or password" |
| TC-03 | Add user | Users → Add User → fill form → Save | User appears in list; activity logged |
| TC-04 | Validation | Submit empty user form | Red error messages under fields |
| TC-05 | Delete user | Click trash icon → confirm | Modal appears; user removed |
| TC-06 | Search | Type a name and click Search | Only matching users shown |
| TC-07 | CSV export | Reports → Export Records | `system_records.csv` downloads |
| TC-08 | Change password | Settings → Change Password | Success message; new password works |
| TC-09 | Responsive | Resize browser < 992 px | Sidebar becomes a slide-in menu |

Run all automated tests with: `python -m unittest discover -s tests -v`

## 9. Conclusion
The System Management System meets its objectives: it provides a secure, user-friendly dashboard to manage
users, records, activities and reports. The use of Flask and SQLite keeps the project simple while still
demonstrating professional practices such as password hashing, input validation, CSRF protection,
audit logging, pagination and automated testing. The project can be demonstrated easily on any computer
and serves as a solid base for larger systems.

## 10. Future Scope
- Role-based access control with several administrator levels.
- Email / SMS notifications and password recovery.
- File uploads and attachments for records.
- REST API and mobile application.
- Advanced analytics, scheduled reports and PDF export.
- Deployment with Gunicorn/Nginx and a PostgreSQL or MySQL database.
- Two-factor authentication and login throttling.
- Dark theme and multi-language interface.
