/* Shared UI behaviour for the System Management System */
document.addEventListener("DOMContentLoaded", function () {
  // Sidebar toggle (mobile)
  var sidebar = document.getElementById("sidebar");
  var backdrop = document.getElementById("sidebarBackdrop");
  var toggle = document.getElementById("sidebarToggle");
  function setSidebar(open) {
    if (!sidebar) return;
    sidebar.classList.toggle("show", open);
    backdrop.classList.toggle("show", open);
  }
  if (toggle) toggle.addEventListener("click", function () { setSidebar(!sidebar.classList.contains("show")); });
  if (backdrop) backdrop.addEventListener("click", function () { setSidebar(false); });

  // Delete confirmation modal
  var modalEl = document.getElementById("deleteModal");
  if (modalEl && window.bootstrap) {
    var modal = new bootstrap.Modal(modalEl);
    document.querySelectorAll(".btn-delete").forEach(function (btn) {
      btn.addEventListener("click", function () {
        document.getElementById("deleteForm").setAttribute("action", btn.dataset.action);
        document.getElementById("deleteName").textContent = btn.dataset.name;
        modal.show();
      });
    });
  }

  // Show / hide password on login page
  var tp = document.getElementById("togglePassword");
  if (tp) {
    tp.addEventListener("click", function () {
      var input = document.getElementById("password");
      var show = input.type === "password";
      input.type = show ? "text" : "password";
      tp.innerHTML = show ? '<i class="fa-solid fa-eye-slash"></i>' : '<i class="fa-solid fa-eye"></i>';
    });
  }

  // Client-side validation (server-side validation is always enforced too)
  document.querySelectorAll("form.needs-validation, form.row.g-3").forEach(function (form) {
    form.addEventListener("submit", function (e) {
      var bad = false;
      form.querySelectorAll("[required]").forEach(function (el) {
        if (!el.value.trim()) { el.classList.add("is-invalid"); bad = true; }
        else { el.classList.remove("is-invalid"); }
      });
      if (bad) { e.preventDefault(); }
    });
  });

  // Auto-dismiss flash alerts after 6 seconds
  setTimeout(function () {
    document.querySelectorAll(".content .alert").forEach(function (a) {
      if (window.bootstrap) bootstrap.Alert.getOrCreateInstance(a).close();
    });
  }, 6000);
});
