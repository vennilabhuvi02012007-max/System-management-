/* Dashboard charts (Chart.js). Expects a global `chartData` object. */
(function () {
  if (typeof Chart === "undefined" || typeof chartData === "undefined") return;
  var palette = ["#6366f1", "#10b981", "#f59e0b", "#ef4444", "#06b6d4", "#8b5cf6", "#64748b"];
  var common = { responsive: true, maintainAspectRatio: false };

  new Chart(document.getElementById("categoryChart"), {
    type: "doughnut",
    data: { labels: chartData.category.labels, datasets: [{ data: chartData.category.data, backgroundColor: palette }] },
    options: Object.assign({}, common, { plugins: { legend: { position: "bottom" } } })
  });

  new Chart(document.getElementById("statusChart"), {
    type: "bar",
    data: { labels: chartData.status.labels, datasets: [{ label: "Records", data: chartData.status.data, backgroundColor: palette, borderRadius: 6 }] },
    options: Object.assign({}, common, { plugins: { legend: { display: false } }, scales: { y: { beginAtZero: true, ticks: { precision: 0 } } } })
  });

  new Chart(document.getElementById("roleChart"), {
    type: "pie",
    data: { labels: chartData.role.labels, datasets: [{ data: chartData.role.data, backgroundColor: palette.slice(1) }] },
    options: Object.assign({}, common, { plugins: { legend: { position: "bottom" } } })
  });

  new Chart(document.getElementById("activityChart"), {
    type: "line",
    data: { labels: chartData.activity.labels, datasets: [{ label: "Activities", data: chartData.activity.data, borderColor: "#6366f1", backgroundColor: "rgba(99,102,241,.15)", fill: true, tension: .35, pointRadius: 4 }] },
    options: Object.assign({}, common, { plugins: { legend: { display: false } }, scales: { y: { beginAtZero: true, ticks: { precision: 0 } } } })
  });
})();
